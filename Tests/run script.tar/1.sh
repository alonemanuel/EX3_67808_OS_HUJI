#!/bin/bash
C=1
while [ 1 ];
do
	echo	
	echo "BEGIN"
	make 1
	echo $C
	let C=C+1
echo
sleep 0.1
done
