#ifndef TESTS_TEST6MAPREDUCE_HPP
#define TESTS_TEST6MAPREDUCE_HPP

#include <iostream>
#include <sstream>
#include <list>

#include "GridKeysValues.hpp"

class GridMapReduce : public MapReduceClient
{
public:

    GridMapReduce() = default;


    /**
     * @param key row number
     * @param val the row itself (string)
     */
    virtual void map(const K1* const key, const V1* const val, void* context)
    const override
    {
        int v, max;
        std::stringstream sstream(((RowString*) val)->getRow());

        // find the maximum value of this row
        sstream >> max;
        while (sstream >> v)
        {
            if (v > max)
            {
                max = v;
            }
        }


        // reset stream
        sstream = std::stringstream(((RowString*) val)->getRow());

        // find all points in this line with the maximum value
        // (all Row-King-Midgets)
        int col = 1;
        int count = 0;
        while (sstream >> v)
        {
            if (v == max)
            {
                // memory should be freed by the framework
                Index *a = new Index(col);
                RowMaxVal *b = new RowMaxVal(((Index*) key)->getIndex(), max);
                emit2(a,b, context);
                count++;
            }

            col++;
        }
    }


    /**
     *
     * @param key column number j
     * @param vals container of pairs - each pair is a row number i and the
     *        height of the point (i,j)
     *        (these are potential candidates to be Shaman-Midgets)
     */
    virtual void reduce(const IntermediateVec* pairs, void* context)
    const override
    {
        int v, max;
        int col = ((Index*) pairs->front().first)->getIndex();

        // initialize max with the value of the first point
        max = ((const RowMaxVal*) pairs->front().second)->getValue();

        //find the maximum value in this column
        for (auto it = pairs->begin(); it != pairs->end(); it++)
        {
            v = ((RowMaxVal*) (*it).second)->getValue();
            if (v > max)
            {
                max = v;
            }
        }


        for (auto it = pairs->begin(); it != pairs->end(); it++)
        {
            v = ((RowMaxVal*) (*it).second)->getValue();

            if (v == max)
            {
                // this memory should be freed by whoever called the
                // framework and holds the vector of results
                GridPoint* point =
                        new GridPoint(((RowMaxVal*) (*it).second)->getRowNum(), col);
                GridPointVal* pointVal = new GridPointVal(v);
                emit3(point, pointVal, context);
            }
        }

    }
};


#endif //TESTS_TEST6MAPREDUCE_HPP
