#ifndef OS_EX3_TEST6KEYSVALUES_HPP
#define OS_EX3_TEST6KEYSVALUES_HPP


#include <string>
#include "MapReduceClient.h"
#include "MapReduceFramework.h"


class Index : public K1, public K2
{
private:
    int index;

public:
    Index(int index)
    {
        this->index = index;
    }

    virtual bool operator<(const K1& other) const override
    {
        return this->index < ((Index&) other).index;
    }

    virtual bool operator<(const K2& other) const override
    {
        return this->index < ((Index&) other).index;
    }

    int getIndex() const
    {
        return index;
    }

};

class GridPoint : public K3
{
private:
    int row, col;

public:
    GridPoint(int row, int col)
    {
        this->row = row;
        this->col = col;
    }

    virtual bool operator<(const K3& other) const override
    {
        if (this->row < ((GridPoint&) other).row)
            return true;

        return (this->row == ((GridPoint&) other).row) &&
               (this->col < ((GridPoint&) other).col);
    }

    int getRow() const
    {
        return row;
    }

    int getCol() const
    {
        return col;
    }
};


class RowString : public V1
{
private:
    std::string row;

public:
    RowString(const char* row)
    {
        this->row = row;
    }

    RowString(const std::string& row)
    {
        this->row = row;
    }

    const std::string& getRow() const
    {
        return row;
    }
};


/**
 * a maximum value of a particular row
 */
class RowMaxVal : public V2
{
private:
    int rowNum;
    int value;

public:
    RowMaxVal(int rowNum, int value)
    {
        this->rowNum = rowNum;
        this->value = value;
    }

    int getRowNum() const
    {
        return rowNum;
    }

    int getValue() const
    {
        return value;
    }

};


class GridPointVal : public V3
{
private:
    int value;

public:
    GridPointVal(int value)
    {
        this->value = value;
    }

    int getValue() const
    {
        return value;
    }

};


#endif //OS_EX3_TEST6KEYSVALUES_HPP
